﻿namespace BoterKaasEieren_OKMON_engine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbField1 = new System.Windows.Forms.PictureBox();
            this.pbField2 = new System.Windows.Forms.PictureBox();
            this.pbField3 = new System.Windows.Forms.PictureBox();
            this.pbField6 = new System.Windows.Forms.PictureBox();
            this.pbField5 = new System.Windows.Forms.PictureBox();
            this.pbField4 = new System.Windows.Forms.PictureBox();
            this.pbField9 = new System.Windows.Forms.PictureBox();
            this.pbField8 = new System.Windows.Forms.PictureBox();
            this.pbField7 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.lblTurn = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbField1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField7)).BeginInit();
            this.SuspendLayout();
            // 
            // pbField1
            // 
            this.pbField1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField1.Location = new System.Drawing.Point(216, 94);
            this.pbField1.Name = "pbField1";
            this.pbField1.Size = new System.Drawing.Size(100, 100);
            this.pbField1.TabIndex = 0;
            this.pbField1.TabStop = false;
            this.pbField1.Click += new System.EventHandler(this.onMove);
            // 
            // pbField2
            // 
            this.pbField2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField2.Location = new System.Drawing.Point(322, 94);
            this.pbField2.Name = "pbField2";
            this.pbField2.Size = new System.Drawing.Size(100, 100);
            this.pbField2.TabIndex = 1;
            this.pbField2.TabStop = false;
            this.pbField2.Click += new System.EventHandler(this.onMove);
            // 
            // pbField3
            // 
            this.pbField3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField3.Location = new System.Drawing.Point(428, 94);
            this.pbField3.Name = "pbField3";
            this.pbField3.Size = new System.Drawing.Size(100, 100);
            this.pbField3.TabIndex = 2;
            this.pbField3.TabStop = false;
            this.pbField3.Click += new System.EventHandler(this.onMove);
            // 
            // pbField6
            // 
            this.pbField6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField6.Location = new System.Drawing.Point(428, 200);
            this.pbField6.Name = "pbField6";
            this.pbField6.Size = new System.Drawing.Size(100, 100);
            this.pbField6.TabIndex = 5;
            this.pbField6.TabStop = false;
            this.pbField6.Click += new System.EventHandler(this.onMove);
            // 
            // pbField5
            // 
            this.pbField5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField5.Location = new System.Drawing.Point(322, 200);
            this.pbField5.Name = "pbField5";
            this.pbField5.Size = new System.Drawing.Size(100, 100);
            this.pbField5.TabIndex = 4;
            this.pbField5.TabStop = false;
            this.pbField5.Click += new System.EventHandler(this.onMove);
            // 
            // pbField4
            // 
            this.pbField4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField4.Location = new System.Drawing.Point(216, 200);
            this.pbField4.Name = "pbField4";
            this.pbField4.Size = new System.Drawing.Size(100, 100);
            this.pbField4.TabIndex = 3;
            this.pbField4.TabStop = false;
            this.pbField4.Click += new System.EventHandler(this.onMove);
            // 
            // pbField9
            // 
            this.pbField9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField9.Location = new System.Drawing.Point(428, 306);
            this.pbField9.Name = "pbField9";
            this.pbField9.Size = new System.Drawing.Size(100, 100);
            this.pbField9.TabIndex = 8;
            this.pbField9.TabStop = false;
            this.pbField9.Click += new System.EventHandler(this.onMove);
            // 
            // pbField8
            // 
            this.pbField8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField8.Location = new System.Drawing.Point(322, 306);
            this.pbField8.Name = "pbField8";
            this.pbField8.Size = new System.Drawing.Size(100, 100);
            this.pbField8.TabIndex = 7;
            this.pbField8.TabStop = false;
            this.pbField8.Click += new System.EventHandler(this.onMove);
            // 
            // pbField7
            // 
            this.pbField7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField7.Location = new System.Drawing.Point(216, 306);
            this.pbField7.Name = "pbField7";
            this.pbField7.Size = new System.Drawing.Size(100, 100);
            this.pbField7.TabIndex = 6;
            this.pbField7.TabStop = false;
            this.pbField7.Click += new System.EventHandler(this.onMove);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 41);
            this.button1.TabIndex = 9;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(555, 158);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(102, 36);
            this.lbl1.TabIndex = 10;
            this.lbl1.Text = "Beurt: ";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(12, 300);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(128, 21);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "tegen computer";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(12, 327);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(151, 21);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "speler tegen speler";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // lblTurn
            // 
            this.lblTurn.AutoSize = true;
            this.lblTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTurn.Location = new System.Drawing.Point(685, 158);
            this.lblTurn.Name = "lblTurn";
            this.lblTurn.Size = new System.Drawing.Size(36, 36);
            this.lblTurn.TabIndex = 13;
            this.lblTurn.Text = "X";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 229);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 65);
            this.button2.TabIndex = 14;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(93, 229);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 65);
            this.button3.TabIndex = 15;
            this.button3.Text = "O";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(674, 25);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 31);
            this.button4.TabIndex = 16;
            this.button4.Text = "debug";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.onDebug);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblTurn);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pbField9);
            this.Controls.Add(this.pbField8);
            this.Controls.Add(this.pbField7);
            this.Controls.Add(this.pbField6);
            this.Controls.Add(this.pbField5);
            this.Controls.Add(this.pbField4);
            this.Controls.Add(this.pbField3);
            this.Controls.Add(this.pbField2);
            this.Controls.Add(this.pbField1);
            this.Name = "Form1";
            this.Text = "OKMON Engine";
            ((System.ComponentModel.ISupportInitialize)(this.pbField1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbField1;
        private System.Windows.Forms.PictureBox pbField2;
        private System.Windows.Forms.PictureBox pbField3;
        private System.Windows.Forms.PictureBox pbField6;
        private System.Windows.Forms.PictureBox pbField5;
        private System.Windows.Forms.PictureBox pbField4;
        private System.Windows.Forms.PictureBox pbField9;
        private System.Windows.Forms.PictureBox pbField8;
        private System.Windows.Forms.PictureBox pbField7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label lblTurn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}

