﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BoterKaasEieren_OKMON_engine
{
    public partial class Form1 : Form
    {
        //image path
        string path = @"D:\coding_projects\SoftwareEngineering\Solutions\week3\BoterKaasEieren_OKMON_engine\images\";
        string[] boardState = new string[10];
        PictureBox[] allFields = new PictureBox[10];
        Random random = new Random();

        /* Win posities
         1, 2,  3
         4, 5,  6
         1, 5,  9
        */
        int[,] winPositions = new int[,] { { 1, 2, 3 }, { 4, 5, 6 }, { 1, 5, 9}};
        public Form1()
        {
            InitializeComponent();
            // Zet de boardstate op leeg
            boardState[0] = ""; // 0 wordt niet gebruikt om het makkelijk te houden
            for (int i = 1; i < boardState.Length; i++)
            {
               // boardState[i] = "empty";
                boardState[i] = i.ToString();
            }

            // nog zorgen dat path relative wordt aan de .exe file
            for (int i = 1; i <= 9; i++)
            {
            PictureBox pb = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
            pb.Image = Image.FromFile(path + "empty.png");
            allFields[i] =  this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
                //pb.Tag = "not started";
            pb.Tag = "empty";
            }
            updateBoardState();
        }

        private void onMove(object sender, EventArgs e)
        {
            turnBoard(1);
            PictureBox clickedBox = sender as PictureBox;
            if (lblTurn.Text == "X" && clickedBox.Tag as string == "empty")
            {
                clickedBox.Image = Image.FromFile(path + lblTurn.Text.ToLower() + ".png");
                clickedBox.Tag = "X";
                updateBoardState();
                checkWinner();
                lblTurn.Text = "O";
            }
            else if(lblTurn.Text == "O" && clickedBox.Tag as string == "empty")
            {
                clickedBox.Image = Image.FromFile(path + lblTurn.Text.ToLower() + ".png");
                clickedBox.Tag = "O";
                updateBoardState();
                checkWinner();
                lblTurn.Text = "X";
            }
            computerMove();
        }


        /* 
         Bord draai functie
         1 naar 3
         2 naar 6
         3 naar 9
         4 naar 2
         5 naar 5
         6 naar 8
         7 naar 1
         8 naar 4
         9 naar 7
             */
        private string[] turnBoard(int turn_times) {
            string[] turnedBoard = new string[10] {"", "empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"};
            string[] boardCopy = (string[])boardState.Clone();

            if (turn_times == 0)
                return boardState;

            for (int i = 0; i < turn_times; i++)
            {
                turnedBoard[3] = boardCopy[1];
                turnedBoard[6] = boardCopy[2];
                turnedBoard[9] = boardCopy[3];
                turnedBoard[2] = boardCopy[4];
                turnedBoard[5] = boardCopy[5]; 
                turnedBoard[8] = boardCopy[6];
                turnedBoard[1] = boardCopy[7];
                turnedBoard[4] = boardCopy[8];
                turnedBoard[7] = boardCopy[9];
                boardCopy = (string[])turnedBoard.Clone();
            }
                return turnedBoard;
            }

        private string checkWinner() {
            // All win positions
            for (int j = 0; j < 3; j++) {
                // Turn the board
                for (int i = 0; i < 4; i++) {
                    string[] board = turnBoard(i);
                    if (board[winPositions[j, 0]] == board[winPositions[j, 1]] && board[winPositions[j, 1]] == board[winPositions[j, 2]] && board[winPositions[j, 0]] != "empty")
                    {
                        MessageBox.Show(lblTurn.Text + " heeft gewonnen!");
                        return lblTurn.Text;
                    }
                } // einde eerste for
            } // einde 2de for
            return "";
        }

        private void updateBoardState() {
            for (int i = 1; i <= 9; i++) {
              PictureBox pb = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
              boardState[i] = pb.Tag as string;
            }
        }
        private void readArray(string[] arr) {
            string fullArray = "";
            for (int i = 0; i < arr.Length; i++)
            {
                fullArray = fullArray + "  " + arr[i];
            }
            MessageBox.Show(fullArray);
        }

        private void computerMove() {
            if (getWinMove() != 0)
            {
                PictureBox pb = this.Controls.Find("pbField" + getWinMove(), true).FirstOrDefault() as PictureBox;
                pb.Tag = "O";
                pb.Image = Image.FromFile(path + lblTurn.Text.ToLower() + ".png");
                updateBoardState();
                checkWinner();
                lblTurn.Text = "X";
            }
            else if (isMiddleEmpty())
                takeMiddle();
            else if (isCornerEmpty())
                takeCorner();
            else
                takeRandom();



        }

       /* private int countWinChances() { // Functie nog niet af
            int winChances = 0;
            // Fake move goes here 
            int[] emptySpaces = getEmpty(counter);
            string[] realboard =  (string[])boardState.Clone(); // Kopie van bord status, zodat het bord hersteld kan worden na de 'fake' moves
            // All win positions
            for (int j = 0; j < 3; j++){
                // Turn the board
                for (int i = 0; i < 4; i++){
                    string[] board = turnBoard(i);
                    if (board[winPositions[j, 0]] == board[winPositions[j, 1]] && board[winPositions[j, 1]] == board[winPositions[j, 2]] && board[winPositions[j, 0]] != "empty")
                    {
                        winChances += 1;
                    }
                } // einde eerste for
            } // einde 2de for
            MessageBox.Show(winChances.ToString());
            return winChances;
        }*/

        private int[] getEmpty(int counter) {
            int[] emptySpaces = new int[9]; // Array voor lege vakjes
            //Array.Clear(emptySpaces, 0, emptySpaces.Length); // Maak de array leeg// Regelt de index in de emptySpace variable
            for (int i = 1; i <= 9; i++)
            {
                if (boardState[i] == "empty")
                {
                    emptySpaces[counter] = i;
                    counter += 1;
                }
            }
            return emptySpaces;
        }

        private void onDebug(object sender, EventArgs e)
        {
            //takeRandom();
            MessageBox.Show(getWinMove().ToString());
        }

        

        // Computer zet functies
        private bool isMiddleEmpty() {
            PictureBox pb = this.Controls.Find("pbField5", true).FirstOrDefault() as PictureBox;
            if (pb.Tag as string == "empty")
                return true;
            else
                return false;
        }

        private void takeMiddle() {
            PictureBox pb = this.Controls.Find("pbField5", true).FirstOrDefault() as PictureBox;
            pb.Tag = "O";
            pb.Image = Image.FromFile(path + lblTurn.Text.ToLower() + ".png");
            updateBoardState();
            checkWinner();
            lblTurn.Text = "X";
        }

        private bool isCornerEmpty() {
            int[] corners = new int[4] {1, 3, 7, 9 }; // lijst van hoeken
            PictureBox currentCorner;

            for (int i = 0; i < 4; i++){
                currentCorner = this.Controls.Find("pbField" + corners[i], true).FirstOrDefault() as PictureBox;
                if (currentCorner.Tag as string == "empty")
                {
                    return true;
                }
            }
            return false;
        }

        private void takeCorner() {
            int counter = 0;
            int[] corners = new int[4] { 1, 3, 7, 9 };
            PictureBox[] emptyCorners = new PictureBox[4];
            PictureBox currentCorner;
            PictureBox pb;
            
            for(int i = 0; i < 4; i ++) {
                currentCorner = this.Controls.Find("pbField"+corners[i], true).FirstOrDefault() as PictureBox;
                if (currentCorner.Tag as string == "empty") {
                    emptyCorners[counter] = currentCorner;
                    counter += 1;
                }
            }
            pb = emptyCorners[random.Next(counter)];
            pb.Tag = "O";
            pb.Image = Image.FromFile(path + lblTurn.Text.ToLower() + ".png");
            updateBoardState();
            checkWinner();
            lblTurn.Text = "X";
        }

        private void takeRandom() {
            int counter = 0;
            PictureBox[] emptyFields = new PictureBox[10];
            PictureBox current;
            PictureBox pb;
            for (int i = 1; i <9; i++)
            {
                current = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
                if (current.Tag as string == "empty") {
                    emptyFields[counter] = current;
                    counter++;
                }
            }
            pb = emptyFields[random.Next(counter)];
            pb.Tag = "O";
            pb.Image = Image.FromFile(path + lblTurn.Text.ToLower() + ".png");
            updateBoardState();
            checkWinner();
            lblTurn.Text = "X";

        }

        // private bool is board full


        private int getWinMove()
        {
            int winChances = 0;
            int counter = 0;
            int[] emptySpaces = new int[9]; // Array voor lege vakjes
            //Array.Clear(emptySpaces, 0, emptySpaces.Length); // Maak de array leeg// Regelt de index in de emptySpace variable
            for (int i = 1; i <= 9; i++)
            {
                if (boardState[i] == "empty")
                {
                    emptySpaces[counter] = i;
                    counter += 1;
                }
            }
            string[] realboard = (string[])boardState.Clone(); // Kopie van bord status, zodat het bord hersteld kan worden na de 'fake' moves
            // Voor elk leeg vakje
            for (int x = 0; x <= counter; x++)
            {
                winChances = 0;
                boardState[emptySpaces[x]] = "X";
                int bestMove = emptySpaces[x];
                //readArray(boardState);
                for (int j = 0; j < 3; j++) // All win positions
                {
                    // Turn the board
                    for (int i = 0; i < 4; i++) // Voor elke draaing van het bord
                    {
                        string[] board = turnBoard(i);
                        //readArray(board);
                        if (board[winPositions[j, 0]] == board[winPositions[j, 1]] && board[winPositions[j, 1]] == board[winPositions[j, 2]] && board[winPositions[j, 0]] != "empty")
                        {
                            //winChances += 1;
                            // return x+1; // zoveelste lege vakje, moet zoveelste vakje worden
                            return bestMove;
                        }
                    } // einde eerste for
                } // einde 2de for
                boardState = (string[])realboard.Clone(); // Herstel het bord
            } // einde 3de for
            return 0;
        }


    }

    }
