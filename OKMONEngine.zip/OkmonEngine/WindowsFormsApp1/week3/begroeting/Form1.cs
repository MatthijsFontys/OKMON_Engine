﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace begroeting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void begroet(object sender, EventArgs e)
        {
            int tijd = DateTime.Now.Hour;
            if (tijd >=6 && tijd < 12)
            {
                MessageBox.Show("Goede morgen");
            }
            else if (tijd >=12 && tijd < 18 )
            {
                MessageBox.Show("Goede middag");
            }
            else if (tijd >=18)
            {
                MessageBox.Show("Goede avond");
            }
            else if (tijd > 24 || tijd < 6) {
                MessageBox.Show("Goede nacht");
            }
        }

    }
}

