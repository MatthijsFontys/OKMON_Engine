﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StringManipulatie
{


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Maak aan het begin de output leeg
            lblOutput.Text = "";
        }

        private void onReverse(object sender, EventArgs e)
        {
            string input = tbInput.Text;
            string output = "";
            int len = input.Length - 1;
            for (int i = 0; i < input.Length; i++){
            output = output + input.Substring(len - i, 1);
            }
            lblOutput.Text = output;
        }

        private void onHaxor(object sender, EventArgs e)
        {
            /* 
            Elke letter a wordt vervangen door een 4.
            Elke letter s wordt vervangen door een 5.
            Elke letter e wordt vervangen door een 3.
            Elke letter l wordt vervangen door een 1.
            Elke letter o wordt vervangen door een 0
            De letters v en V wordt vervangen door \/.
            De letters m en M worden vervangen door |V|.
            */

            string input = tbInput.Text;
            string output = "";
            string current;
            int len = input.Length - 1;
            for (int i = 0; i < input.Length; i++){
                current = input.Substring(i, 1);
                switch (current)
                {
                    case "a":
                        current = "4";
                        break;
                    case "s":
                        current = "5";
                        break;
                    case "e":
                        current = "3";
                        break;
                    case "l":
                        current = "1";
                        break;
                    case "o":
                        current = "0";
                        break;
                    case "A":
                        current = "4";
                        break;
                    case "S":
                        current = "5";
                        break;
                    case "E":
                        current = "3";
                        break;
                    case "L":
                        current = "1";
                        break;
                    case "O":
                        current = "0";
                        break;
                    case "v":
                        current = @"\/"; // @, zodat c# denkt dat het een path is
                        break;
                    case "V":
                        current = @"\/"; // @, zodat c# denkt dat het een path is
                        break;
                    case "m":
                        current = "|V|";
                        break;
                    case "M":
                        current = "|V|";
                        break;
                    default:
                        break;
                }
                output = output + current;
            }
            lblOutput.Text = output;
        }
    }
}
