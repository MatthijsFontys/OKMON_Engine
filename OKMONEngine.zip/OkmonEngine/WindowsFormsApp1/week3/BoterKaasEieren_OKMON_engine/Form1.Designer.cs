﻿namespace BoterKaasEieren_OKMON_engine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbField1 = new System.Windows.Forms.PictureBox();
            this.pbField2 = new System.Windows.Forms.PictureBox();
            this.pbField3 = new System.Windows.Forms.PictureBox();
            this.pbField6 = new System.Windows.Forms.PictureBox();
            this.pbField5 = new System.Windows.Forms.PictureBox();
            this.pbField4 = new System.Windows.Forms.PictureBox();
            this.pbField9 = new System.Windows.Forms.PictureBox();
            this.pbField8 = new System.Windows.Forms.PictureBox();
            this.pbField7 = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblTurnPrefix = new System.Windows.Forms.Label();
            this.rbComputer = new System.Windows.Forms.RadioButton();
            this.rbHuman = new System.Windows.Forms.RadioButton();
            this.lblTurn = new System.Windows.Forms.Label();
            this.btnX = new System.Windows.Forms.Button();
            this.btnO = new System.Windows.Forms.Button();
            this.lbLog = new System.Windows.Forms.ListBox();
            this.btnComputerMode = new System.Windows.Forms.Button();
            this.lblGameCount = new System.Windows.Forms.Label();
            this.tbImport = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDebug = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnHint = new System.Windows.Forms.Button();
            this.btnOkmonBattle = new System.Windows.Forms.Button();
            this.tbSpeed = new System.Windows.Forms.TextBox();
            this.lblDelay = new System.Windows.Forms.Label();
            this.btnDeveloper = new System.Windows.Forms.Button();
            this.btnClearLog = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbField1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField7)).BeginInit();
            this.SuspendLayout();
            // 
            // pbField1
            // 
            this.pbField1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField1.Location = new System.Drawing.Point(216, 94);
            this.pbField1.Name = "pbField1";
            this.pbField1.Size = new System.Drawing.Size(100, 100);
            this.pbField1.TabIndex = 0;
            this.pbField1.TabStop = false;
            this.pbField1.Click += new System.EventHandler(this.field_click);
            // 
            // pbField2
            // 
            this.pbField2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField2.Location = new System.Drawing.Point(322, 94);
            this.pbField2.Name = "pbField2";
            this.pbField2.Size = new System.Drawing.Size(100, 100);
            this.pbField2.TabIndex = 1;
            this.pbField2.TabStop = false;
            this.pbField2.Click += new System.EventHandler(this.field_click);
            // 
            // pbField3
            // 
            this.pbField3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField3.Location = new System.Drawing.Point(428, 94);
            this.pbField3.Name = "pbField3";
            this.pbField3.Size = new System.Drawing.Size(100, 100);
            this.pbField3.TabIndex = 2;
            this.pbField3.TabStop = false;
            this.pbField3.Click += new System.EventHandler(this.field_click);
            // 
            // pbField6
            // 
            this.pbField6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField6.Location = new System.Drawing.Point(428, 200);
            this.pbField6.Name = "pbField6";
            this.pbField6.Size = new System.Drawing.Size(100, 100);
            this.pbField6.TabIndex = 5;
            this.pbField6.TabStop = false;
            this.pbField6.Click += new System.EventHandler(this.field_click);
            // 
            // pbField5
            // 
            this.pbField5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField5.Location = new System.Drawing.Point(322, 200);
            this.pbField5.Name = "pbField5";
            this.pbField5.Size = new System.Drawing.Size(100, 100);
            this.pbField5.TabIndex = 4;
            this.pbField5.TabStop = false;
            this.pbField5.Click += new System.EventHandler(this.field_click);
            // 
            // pbField4
            // 
            this.pbField4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField4.Location = new System.Drawing.Point(216, 200);
            this.pbField4.Name = "pbField4";
            this.pbField4.Size = new System.Drawing.Size(100, 100);
            this.pbField4.TabIndex = 3;
            this.pbField4.TabStop = false;
            this.pbField4.Click += new System.EventHandler(this.field_click);
            // 
            // pbField9
            // 
            this.pbField9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField9.Location = new System.Drawing.Point(428, 306);
            this.pbField9.Name = "pbField9";
            this.pbField9.Size = new System.Drawing.Size(100, 100);
            this.pbField9.TabIndex = 8;
            this.pbField9.TabStop = false;
            this.pbField9.Click += new System.EventHandler(this.field_click);
            // 
            // pbField8
            // 
            this.pbField8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField8.Location = new System.Drawing.Point(322, 306);
            this.pbField8.Name = "pbField8";
            this.pbField8.Size = new System.Drawing.Size(100, 100);
            this.pbField8.TabIndex = 7;
            this.pbField8.TabStop = false;
            this.pbField8.Click += new System.EventHandler(this.field_click);
            // 
            // pbField7
            // 
            this.pbField7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbField7.Location = new System.Drawing.Point(216, 306);
            this.pbField7.Name = "pbField7";
            this.pbField7.Size = new System.Drawing.Size(100, 100);
            this.pbField7.TabIndex = 6;
            this.pbField7.TabStop = false;
            this.pbField7.Click += new System.EventHandler(this.field_click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(12, 365);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(100, 41);
            this.btnStart.TabIndex = 9;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblTurnPrefix
            // 
            this.lblTurnPrefix.AutoSize = true;
            this.lblTurnPrefix.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTurnPrefix.Location = new System.Drawing.Point(214, 35);
            this.lblTurnPrefix.Name = "lblTurnPrefix";
            this.lblTurnPrefix.Size = new System.Drawing.Size(102, 36);
            this.lblTurnPrefix.TabIndex = 10;
            this.lblTurnPrefix.Text = "Beurt: ";
            // 
            // rbComputer
            // 
            this.rbComputer.AutoSize = true;
            this.rbComputer.Checked = true;
            this.rbComputer.Location = new System.Drawing.Point(12, 300);
            this.rbComputer.Name = "rbComputer";
            this.rbComputer.Size = new System.Drawing.Size(128, 21);
            this.rbComputer.TabIndex = 11;
            this.rbComputer.TabStop = true;
            this.rbComputer.Text = "tegen computer";
            this.rbComputer.UseVisualStyleBackColor = true;
            // 
            // rbHuman
            // 
            this.rbHuman.AutoSize = true;
            this.rbHuman.Location = new System.Drawing.Point(12, 327);
            this.rbHuman.Name = "rbHuman";
            this.rbHuman.Size = new System.Drawing.Size(151, 21);
            this.rbHuman.TabIndex = 12;
            this.rbHuman.Text = "speler tegen speler";
            this.rbHuman.UseVisualStyleBackColor = true;
            // 
            // lblTurn
            // 
            this.lblTurn.AutoSize = true;
            this.lblTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTurn.Location = new System.Drawing.Point(316, 35);
            this.lblTurn.Name = "lblTurn";
            this.lblTurn.Size = new System.Drawing.Size(36, 36);
            this.lblTurn.TabIndex = 13;
            this.lblTurn.Text = "X";
            // 
            // btnX
            // 
            this.btnX.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnX.Location = new System.Drawing.Point(12, 229);
            this.btnX.Name = "btnX";
            this.btnX.Size = new System.Drawing.Size(75, 65);
            this.btnX.TabIndex = 14;
            this.btnX.Text = "X";
            this.btnX.UseVisualStyleBackColor = true;
            this.btnX.Click += new System.EventHandler(this.btnX_Click);
            // 
            // btnO
            // 
            this.btnO.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnO.Location = new System.Drawing.Point(93, 229);
            this.btnO.Name = "btnO";
            this.btnO.Size = new System.Drawing.Size(75, 65);
            this.btnO.TabIndex = 15;
            this.btnO.Text = "O";
            this.btnO.UseVisualStyleBackColor = true;
            this.btnO.Click += new System.EventHandler(this.btnO_Click);
            // 
            // lbLog
            // 
            this.lbLog.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLog.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.lbLog.FormattingEnabled = true;
            this.lbLog.ItemHeight = 24;
            this.lbLog.Location = new System.Drawing.Point(612, 66);
            this.lbLog.Name = "lbLog";
            this.lbLog.Size = new System.Drawing.Size(162, 340);
            this.lbLog.TabIndex = 17;
            // 
            // btnComputerMode
            // 
            this.btnComputerMode.Location = new System.Drawing.Point(12, 66);
            this.btnComputerMode.Name = "btnComputerMode";
            this.btnComputerMode.Size = new System.Drawing.Size(115, 49);
            this.btnComputerMode.TabIndex = 18;
            this.btnComputerMode.Text = "OKMON vs Random";
            this.btnComputerMode.UseVisualStyleBackColor = true;
            this.btnComputerMode.Click += new System.EventHandler(this.btnComputerMode_Click);
            // 
            // lblGameCount
            // 
            this.lblGameCount.AutoSize = true;
            this.lblGameCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGameCount.Location = new System.Drawing.Point(12, 174);
            this.lblGameCount.Name = "lblGameCount";
            this.lblGameCount.Size = new System.Drawing.Size(85, 20);
            this.lblGameCount.TabIndex = 19;
            this.lblGameCount.Text = "Gespeeld:";
            // 
            // tbImport
            // 
            this.tbImport.Location = new System.Drawing.Point(367, 66);
            this.tbImport.Name = "tbImport";
            this.tbImport.Size = new System.Drawing.Size(209, 22);
            this.tbImport.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(367, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 51);
            this.button1.TabIndex = 21;
            this.button1.Text = "Importeer bord";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnDebug
            // 
            this.btnDebug.Location = new System.Drawing.Point(715, 19);
            this.btnDebug.Name = "btnDebug";
            this.btnDebug.Size = new System.Drawing.Size(82, 31);
            this.btnDebug.TabIndex = 16;
            this.btnDebug.Text = "debug";
            this.btnDebug.UseVisualStyleBackColor = true;
            this.btnDebug.Click += new System.EventHandler(this.onDebug);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(476, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 51);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "Opslaan";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnHint
            // 
            this.btnHint.Location = new System.Drawing.Point(582, 12);
            this.btnHint.Name = "btnHint";
            this.btnHint.Size = new System.Drawing.Size(103, 48);
            this.btnHint.TabIndex = 23;
            this.btnHint.Text = "Hint";
            this.btnHint.UseVisualStyleBackColor = true;
            this.btnHint.Click += new System.EventHandler(this.btnHint_Click);
            // 
            // btnOkmonBattle
            // 
            this.btnOkmonBattle.Location = new System.Drawing.Point(12, 122);
            this.btnOkmonBattle.Name = "btnOkmonBattle";
            this.btnOkmonBattle.Size = new System.Drawing.Size(115, 49);
            this.btnOkmonBattle.TabIndex = 24;
            this.btnOkmonBattle.Tag = "OKMON";
            this.btnOkmonBattle.Text = "OKMON vs OKMON";
            this.btnOkmonBattle.UseVisualStyleBackColor = true;
            this.btnOkmonBattle.Click += new System.EventHandler(this.btnComputerMode_Click);
            // 
            // tbSpeed
            // 
            this.tbSpeed.Location = new System.Drawing.Point(127, 35);
            this.tbSpeed.Name = "tbSpeed";
            this.tbSpeed.Size = new System.Drawing.Size(70, 22);
            this.tbSpeed.TabIndex = 25;
            // 
            // lblDelay
            // 
            this.lblDelay.AutoSize = true;
            this.lblDelay.Location = new System.Drawing.Point(100, 9);
            this.lblDelay.Name = "lblDelay";
            this.lblDelay.Size = new System.Drawing.Size(139, 17);
            this.lblDelay.TabIndex = 26;
            this.lblDelay.Text = "Computer delay (ms)";
            // 
            // btnDeveloper
            // 
            this.btnDeveloper.Location = new System.Drawing.Point(9, 12);
            this.btnDeveloper.Name = "btnDeveloper";
            this.btnDeveloper.Size = new System.Drawing.Size(88, 44);
            this.btnDeveloper.TabIndex = 27;
            this.btnDeveloper.Text = "developer mode";
            this.btnDeveloper.UseVisualStyleBackColor = true;
            this.btnDeveloper.Click += new System.EventHandler(this.btnDeveloper_Click);
            // 
            // btnClearLog
            // 
            this.btnClearLog.Location = new System.Drawing.Point(635, 415);
            this.btnClearLog.Name = "btnClearLog";
            this.btnClearLog.Size = new System.Drawing.Size(112, 31);
            this.btnClearLog.TabIndex = 28;
            this.btnClearLog.Text = "leeg";
            this.btnClearLog.UseVisualStyleBackColor = true;
            this.btnClearLog.Click += new System.EventHandler(this.btnClearLog_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClearLog);
            this.Controls.Add(this.btnDeveloper);
            this.Controls.Add(this.lblDelay);
            this.Controls.Add(this.tbSpeed);
            this.Controls.Add(this.btnOkmonBattle);
            this.Controls.Add(this.btnHint);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbImport);
            this.Controls.Add(this.lblGameCount);
            this.Controls.Add(this.btnComputerMode);
            this.Controls.Add(this.lbLog);
            this.Controls.Add(this.btnDebug);
            this.Controls.Add(this.btnO);
            this.Controls.Add(this.btnX);
            this.Controls.Add(this.lblTurn);
            this.Controls.Add(this.rbHuman);
            this.Controls.Add(this.rbComputer);
            this.Controls.Add(this.lblTurnPrefix);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.pbField9);
            this.Controls.Add(this.pbField8);
            this.Controls.Add(this.pbField7);
            this.Controls.Add(this.pbField6);
            this.Controls.Add(this.pbField5);
            this.Controls.Add(this.pbField4);
            this.Controls.Add(this.pbField3);
            this.Controls.Add(this.pbField2);
            this.Controls.Add(this.pbField1);
            this.Name = "Form1";
            this.Text = "OKMON Engine";
            ((System.ComponentModel.ISupportInitialize)(this.pbField1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbField7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbField1;
        private System.Windows.Forms.PictureBox pbField2;
        private System.Windows.Forms.PictureBox pbField3;
        private System.Windows.Forms.PictureBox pbField6;
        private System.Windows.Forms.PictureBox pbField5;
        private System.Windows.Forms.PictureBox pbField4;
        private System.Windows.Forms.PictureBox pbField9;
        private System.Windows.Forms.PictureBox pbField8;
        private System.Windows.Forms.PictureBox pbField7;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblTurnPrefix;
        private System.Windows.Forms.RadioButton rbComputer;
        private System.Windows.Forms.RadioButton rbHuman;
        private System.Windows.Forms.Label lblTurn;
        private System.Windows.Forms.Button btnX;
        private System.Windows.Forms.Button btnO;
        private System.Windows.Forms.ListBox lbLog;
        private System.Windows.Forms.Button btnComputerMode;
        private System.Windows.Forms.Label lblGameCount;
        private System.Windows.Forms.TextBox tbImport;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnDebug;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnHint;
        private System.Windows.Forms.Button btnOkmonBattle;
        private System.Windows.Forms.TextBox tbSpeed;
        private System.Windows.Forms.Label lblDelay;
        private System.Windows.Forms.Button btnDeveloper;
        private System.Windows.Forms.Button btnClearLog;
    }
}

