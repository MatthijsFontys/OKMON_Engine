﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndexVanE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void onClick(object sender, EventArgs e)
        {



            string input = tbInput.Text;
            int output = input.IndexOf("e");
            if (output == -1)
            {
                lblOutput.Text = "10";
            }
            else {
                lblOutput.Text = Convert.ToString(output);
            }





        }
    }
}
